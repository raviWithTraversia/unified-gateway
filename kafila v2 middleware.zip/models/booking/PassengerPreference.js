const mongoose = require("mongoose");
const passengerPreferenceSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
    },
    bookingId: {
      type: String,
      default: null,
    },
    bid: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "BookingDetails",
    },
    GstData: {
      gstNumber: { type: String, default: null },
      gstName: { type: String, default: null },
      gstmobile: { type: String, default: null },
      gstEmail: { type: String, default: null },
      gstAddress: { type: String, default: null },
      GSTState: { type: String, default: "" },
      GSTPinCode: { type: String, default: "" },
      isAgentGst: { type: Boolean, default: false },
    },
    PaxEmail: { type: String, default: null },
    PaxMobile: { type: String, default: null },
    Passengers: [
      {
        eTime:{type:Date,default:Date.now()},
        errorMessage: { type: String, default: null },
        accountPost: { type: String, default: "0" },
        PaxType: { type: String, default: null },
        passengarSerialNo: { type: Number, default: null },
        Title: { type: String, default: null },
        FName: { type: String, default: null },
        LName: { type: String, default: null },
        Gender: { type: String, default: null },
        Dob: { type: String, default: null },
        AmendmentType: { type: Boolean, default: false },
        Status: { type: String, default: null },
        barCode2D: [
          {
            FCode: { type: String, default: null },
            FNo: { type: String, default: null },
            Src: { type: String, default: null },
            Des: { type: String, default: null },
            Code: { type: String, default: null },
          },
        ],
        Optional: {
          ticketDetails: [
            {
              ticketNumber: {
                type: String,
                default: null,
              },
              status:{
                type:String,
                default:""
              },
              src: {
                type: String,
                default: null,
              },
              des: {
                type: String,
                default: null,
              },
            },
          ],
          EMDDetails: [
            {
              EMDNumber: {
                type: String,
                default: null,
              },
              IssuedDate: {
                type: String,
                default: null,
              },
              amount: {
                type: Number,
                default: null,
              },
              currency: {
                type: String,
                default: null,
              },
              type: {
                type: String,
                default: null,
              },
              status: {
                type: String,
                default: null,
              },
              origin: {
                type: String,
                default: null,
              },
              destination: {
                type: String,
                default: null,
              },
            },
          ],
          PassportNo: { type: String, default: null },
          PassportExpiryDate: { type: String, default: null },
          PassportIssuedDate: { type: String, default: null },
          FrequentFlyerNo: { type: String, default: null },
          Nationality: { type: String, default: null },
          ResidentCountry: { type: String, default: null },
        },
        Meal: [
          {
            Trip: { type: String, default: null },
            FCode: { type: String, default: null },
            FNo: { type: String, default: null },
            SsrCode: { type: String, default: null },
            SsrDesc: { type: String, default: null },
            Complmnt: { type: String, default: true },
            Currency: { type: String, default: null },
            Price: { type: Number, default: 0 },
            rePrice: { type: Number, default: 0 },
            Src: { type: String, default: null },
            Des: { type: String, default: null },
            SsrFor: { type: String, default: null },
            OI: { type: String, default: null },
          },
        ],
        Baggage: [
          {
            Trip: { type: String, default: null },
            FCode: { type: String, default: null },
            FNo: { type: String, default: null },
            SsrCode: { type: String, default: null },
            SsrDesc: { type: String, default: null },
            Complmnt: { type: String, default: true },
            Currency: { type: String, default: null },
            Price: { type: Number, default: 0 },
            rePrice: { type: Number, default: 0 },
            Src: { type: String, default: null },
            Des: { type: String, default: null },
            SsrFor: { type: String, default: null },
            OI: { type: String, default: null },
          },
        ],
        Seat: [
          {
            Trip: { type: String, default: null },
            FCode: { type: String, default: null },
            FNo: { type: String, default: null },
            SsrCode: { type: String, default: null },
            SsrDesc: { type: String, default: null },
            Complmnt: { type: String, default: true },
            Currency: { type: String, default: null },
            Price: { type: Number, default: 0 },
            TotalPrice: { type: Number, default: 0 },
            Src: { type: String, default: null },
            SeatCode: { type: String, default: null },
            Des: { type: String, default: null },
            SsrFor: { type: String, default: null },
            OI: { type: String, default: null },
          },
        ],
        FastForward: [
          {
            Complmnt: { type: String, default: true },
            Paid: { type: String, default: true },
            FNo: { type: String, default: null },
            Currency: { type: String, default: null },
            FCode: { type: String, default: null },
            FNo: { type: String, default: null },
            OI: { type: String, default: null },
            Price: { type: Number, default: 0 },
            SsrCode: { type: String, default: null },
            SsrDesc: { type: String, default: null },
            SsrFor: { type: String, default: null },
            Trip: { type: String, default: null },
            Src: { type: String, default: null },
            Des: { type: String, default: null },
          },
        ],
        totalPublishedPrice: { type: Number, default: 0 },
        totalBaggagePrice: { type: Number, default: 0 },
        totalMealPrice: { type: Number, default: 0 },
        totalSeatPrice: { type: Number, default: 0 },
        totalFastForwardPrice: { type: Number, default: 0 },
      },
      { _id: true },
    ],
    modifyBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    modifyAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

const PassengerPreference = mongoose.model(
  "PassengerPreference",
  passengerPreferenceSchema
);

module.exports = PassengerPreference;
