const express = require("express");
const payu_route = express();
const bodyParser = require("body-parser");
payu_route.use(bodyParser.json());
payu_route.use(bodyParser.urlencoded({extended:true}));
const auth = require("../middleware/auth");
const payuController = require('./../controllers/payuController/payu.controller');
const lyraService=require('../controllers/lyraPg/lyraService')
const lyraController=require('../controllers/lyraPg/lyraController')

payu_route.post(
    '/paymentGateway/payu',
    auth,
    payuController.payu
);

payu_route.post(
    '/paymentGateway/success',
    payuController.payuSuccess
);

payu_route.post(
    '/paymentGateway/success-payu-wallet-response',
    payuController.payuWalletResponceSuccess
);

payu_route.post(
    '/paymentGateway/success-payu-wallet-rail-response',
    payuController.payuWalletRailResponceSuccess
);
payu_route.post(
    '/paymentGateway/failed-payu-wallet-response',
    payuController.payuWalletResponceFailed
);

payu_route.post(
    '/paymentGateway/failed',
    payuController.payuFail
);

payu_route.post("/rail/paymentGateway/failed",payuController.railPayuFail)

payu_route.post(
    '/rail/paymentGateway/success',
    payuController.railPayuSuccess
);

payu_route.post(
    '/paymentGateway/payu2',
    auth,
    payuController.payu2
);

payu_route.post("/flight/hold-process",payuController.payuHoldProecess)

payu_route.post('/lyra/redirect',auth,lyraService.lyraRedirectLink)
payu_route.post('/lyra/success',lyraController.lyraSuccess )
payu_route.post('/flight/lyra/wallet/success',lyraController.lyraWalletResponceSuccess )
payu_route.post('/rail/lyra/wallet/success',lyraController.railPayuSuccess )

payu_route.get('/test',auth, function(req, res){
    res.status(200).json({status:"success",msg:"this is test responce"});
});

module.exports = payu_route;
