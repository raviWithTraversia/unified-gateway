const CreditRequest = require('../../models/CreditRequest');
const Company = require('../../models/Company');
const User = require('../../models/User');
const commonFunction = require('../commonFunctions/common.function');


const addCreditRequest = async(req , res) => {
    try {
        const {companyId,
            date,
            duration,
            purpose,
            amount,
            utilizeAmount,
            remarks,
            expireDate,
            createdDate,
            createdBy,
            requestedAmount,
        } = req.body;

        if(!companyId || !createdBy || !requestedAmount) {
            return {
                response : 'All field are required'
            }
        }

        // check companyId exist or not
        const checkExistCompany = await Company.findById(companyId);
        if(!checkExistCompany) {
            return {
                response : 'companyId does not exist'
            }
        }

        // Check created BY id exist or not
        const checkUserIdExist = await User.findById(createdBy);
        if(!checkUserIdExist) {
            return {
                response : 'createdBy id does not exist'
            }
        }
        const saveResult = new CreditRequest({
            companyId,
            date,
            duration,
            purpose,
            amount,
            utilizeAmount,
            remarks,
            expireDate,
            createdDate,
            createdBy,
            requestedAmount 
        })
        
        const result = await saveResult.save();
        
        // Log add 
        const doerId = req.user._id;
        const loginUser = await User.findById(doerId);

        await commonFunction.eventLogFunction(
            'creditRequest' ,
            doerId ,
            loginUser.fname ,
            req.ip , 
            companyId , 
            'add credit request'
        );

        return {
            response : 'Credit request created successfully'
        }

    } catch (error) {
        throw error;
    }
}

const getAllCreditList = async(req , res) => {
    try {
        const result = await CreditRequest.find();
        if (result.length > 0) {
            return {
                data: result
            }
        } else {
            return {
                response: 'Credit request not available',
                data: null
            }
        }

    } catch (error) {
        throw error;
    }
}



const getCredirRequestByCompanyId = async(req , res) => {
    try {
        const CompanyId = req.params.companyId;
        const result = await CreditRequest.find({companyId : CompanyId});
        if (result.length > 0) {
            return {
                data: result
            }
        } else {
            return {
                response: 'Credit request not available',
                data: null
            }
        }

    } catch (error) {
        throw error;
    }
}

// accept and reject credit request

const approveAndRejectCredit = async(req, res) => {
    try {
        const {expireDate , utilizeAmount , remarks , status} = req.body;
        const _id = req.params.creditRequestId;
        if(!remarks || !status) {
            return {
                response : 'Remark and status are required'
            }
        }
        if(status == "approved") {
            if(!expireDate || !utilizeAmount) {
                return {
                    response : 'All field are required',
                }
            }

            
            const doerId = req.user._id;
            const loginUser = await User.findById(doerId);
    
            // Approved
            const updateCreditRequestApproved =  await CreditRequest.findByIdAndUpdate(_id, {
                expireDate,
                utilizeAmount,
                remarks,
                status,
                amount: utilizeAmount
            }, { new: true })

            await commonFunction.eventLogFunction(
                'creditRequest' ,
                doerId ,
                loginUser.fname ,
                req.ip , 
                loginUser.company_ID , 
                'Credit request approved'
            );
            return {
                response : 'Credit request approved successfully'
            }
        }else{

            // Rejected
            const updateCreditRequestRejected =  await CreditRequest.findByIdAndUpdate(_id, {
                remarks,
                status,
            }, { new: true })

            await commonFunction.eventLogFunction(
                'creditRequest' ,
                doerId ,
                loginUser.fname ,
                req.ip , 
                loginUser.company_ID , 
                'Credit request rejected'
            );
            return {
                response : 'Credit request rejected successfully'
            }
        }

    } catch (error) {
       throw error 
    }
}

module.exports = {
     addCreditRequest ,
     getAllCreditList , 
     getCredirRequestByCompanyId ,
     approveAndRejectCredit
    }