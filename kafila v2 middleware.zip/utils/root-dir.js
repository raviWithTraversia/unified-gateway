const path = require("path");

const ROOT_DIR = path.dirname(__dirname);
module.exports = { ROOT_DIR };
