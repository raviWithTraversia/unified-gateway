const express = require("express");
const rail_route = express();
const bodyParser = require("body-parser");
rail_route.use(bodyParser.json());
rail_route.use(bodyParser.urlencoded({ extended: true }));
const auth = require("../middleware/auth");
const railController = require("./../controllers/rail/rail.controller");
const railBookingController = require("../controllers/rail/RailBooking.js/railbooking.controller");
const balance = require("../controllers/rail/railBalance/manualDebitCreditRails.controller");
rail_route.post("/rail/railSearch", auth, railController.railSearch);
rail_route.post(
  "/rail/railSearchBtwnDate",
  auth,
  railController.railSearchBtwnDate
);
rail_route.post("/rail/stationName", auth, railController.getTrainStation);
rail_route.post("/rail/railRoute", auth, railController.getTrainRoute);
rail_route.post("/rail/create-station-master",auth,railController.createTrainStation);
rail_route.patch("/rail/update-station-master",auth,railController.updateTrainStation);
rail_route.post("/rail/fareEnquiry", auth, railController.getFareEnquiry);
rail_route.post("/rail/get-boarding-station", auth, railController.getBoardingStation);
rail_route.post("/rail/Change-boarding-station", auth, railController.ChangeBoardingStation);
rail_route.post("/rail/Pnr-enquiry", railController.PnrEnquirry);



rail_route.post("/rail/manualDebitCredit", auth, balance.manualDebitCredit);
rail_route.post("/rail/bookingSave", railController.DecodeToken);
rail_route.post("/rail/start-booking", railBookingController.StartBookingRail);
rail_route.post(
  "/rail/get-all-booking",
  railBookingController.findRailAllBooking
);
rail_route.get(
  "/getAgent-performance/:parentId",
  auth,
  balance.agentPerformanceReport
);
rail_route.post(
  "/rail/cancellation-charges",
  railController.fetchCancellationCharges
);
rail_route.post("/rail/cancel-booking", railController.cancelBooking);
rail_route.post("/rail/refund-details", railController.fetchRefundDetails);
rail_route.put(
  "/rail/cancel-booking",
  auth,
  railController.updateCancellationDetails
);
rail_route.post(
  "/rail/cancel-booking/verify-otp",
  railController.verifyCancellationOTP
);
rail_route.post(
  "/rail/cancel-booking/resend-otp",
  railController.resendCancellationOTP
);
rail_route.post("/rail/cancellations", railController.fetchCancellations);
rail_route.post("/rail/txn-history", railController.handleFetchTxnHistory);
rail_route.get("/rail/tdr-reasons", railController.handleFetchTDRReasons);
rail_route.post("/rail/file-tdr", railController.handleTDRRequest);
rail_route.post("/railbooking/getProvideStatusCount",railBookingController.getProvideStatusCount)

// easeBuzz_route.post('/paymentGateway/easeBussResponce', auth, easeBuzzController.easeBuzzResponce);

module.exports = rail_route;
