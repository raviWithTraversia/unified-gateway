const PrivilagePlan = require('../../models/PrivilagePlan');
const Company = require('../../models/Company');
const ProductPlan = require('../../models/ProductPlan');
const privilagePlanHasPermission = require('../../models/PrivilagePlanHasPermission')
const User = require('../../models/User');
const commonFunction = require('../commonFunctions/common.function');

const addPrivilagePlan = async(req , res) =>{
    try {
        
        const {companyId , privilagePlanName , productPlanId , permission} = req.body;
        if(!companyId || !privilagePlanName || !productPlanId || !permission) {
            return {
                response : 'All field are required'
            }
        }
        // check company id exits or not
        const checkCompanyExist = await Company.findById(companyId);
        if (!checkCompanyExist) {
            return {
                response: "companyId does not exist"
            }
        }
       
        // check product plan id exist or not
        const checkProductPlanExist = await ProductPlan.findById(productPlanId);
        if (!checkProductPlanExist) {
            return {
                response: "product plan Id does not exist"
            }
        }

        // check privilage name already exist behalf of company id
        const checkPrivilagePlanNameExist = await PrivilagePlan.find({ privilagePlanName : privilagePlanName , companyId : companyId});
       
        if (checkPrivilagePlanNameExist.length > 0) {
            return {
                response: 'privilage plan name already exist'
            }
        }

        const addPrivilage = new PrivilagePlan({
            companyId,
            privilagePlanName,
            productPlanId
        });

        const result = await addPrivilage.save();

        const privilagePlanId = result._id;

        // Add privilagePlanHasPermission
        permission.forEach(async(permission) => {
            const permissionId = permission.permissionId;
            const privilagePlanAdd = new privilagePlanHasPermission({
                privilagePlanId,
                permissionId
            });
           const result = await privilagePlanAdd.save();
        });


        // Log add 
        const doerId = req.user._id;
        const loginUser = await User.findById(doerId);

        await commonFunction.eventLogFunction(
            'privilagePlan' ,
            doerId ,
            loginUser.fname ,
            req.ip , 
            companyId , 
            'Privilage plan add'
        );

        return {    
            response : 'Privilage plan created successfully'
        }

    } catch (error) {
        throw error
    }
}

const getPrivilageList =async(req ,res) => {
    try {
        const companyId = req.params.comapnyId;
        const result = await PrivilagePlan.find({companyId : companyId});
        if (result.length > 0) {
            return {
                data: result
            }
        } else {
            return {
                response: 'Privilage Plan Not Found',
                data: null
            }
        }

    } catch (error) {
        throw error;
    }
}

// Get privilage plab by product id
const getPrivilagePlanByProductPlanId =async(req ,res) => {
    try {
        const productPlanId = req.params.productPlanId;
        const result = await PrivilagePlan.find({productPlanId : productPlanId});
        if (result.length > 0) {
            return {
                data: result
            }
        } else {
            return {
                response: 'Privilage Plan Not Found',
                data: null
            }
        }

    } catch (error) {
        throw error;
    }
}

// Get privilage plan has product by privilage id
const privilagePHPByPrivilageId =async(req ,res) => {
    try {
        const privilagePlanId = req.params.privilagePlanId;
        const result = await privilagePlanHasPermission.find({privilagePlanId : privilagePlanId});
        if (result.length > 0) {
            return {
                data: result
            }
        } else {
            return {
                response: 'Privilage Plan Not Found',
                data: null
            }
        }

    } catch (error) {
        throw error;
    }
}

// privilage Plan update method 

const privilagePlanPatch = async(req , res) => {
    try {
       
        const {companyId ,privilagePlanName , productPlanId , permission} = req.body;
        if(!companyId || !privilagePlanName || !productPlanId || !permission) {
            return {
                response : 'All field are required'
            }
        }

         // check company id exits or not
         const checkCompanyExist = await Company.findById(companyId);
         if (!checkCompanyExist) {
             return {
                 response: "companyId does not exist"
             }
         }
       
        // check product plan id exist or not
        const checkProductPlanExist = await ProductPlan.findById(productPlanId);
        if (!checkProductPlanExist) {
            return {
                response: "product plan Id does not exist"
            }
        }

        const _id = req.params.privilagePlanId;
        const privilagePlanId = req.params.privilagePlanId;
        // check privilage name already exist behalf of company id
        const checkPrivilagePlanNameExist = await PrivilagePlan.findOne({ _id : _id});
        
        if (privilagePlanName != checkPrivilagePlanNameExist.privilagePlanName) {
            
            const checkPrivilage = await PrivilagePlan.find({ companyId : companyId });
           
            const oldNameExists = checkPrivilage.some(checkPrivilage => checkPrivilage.privilagePlanName.toLowerCase() === privilagePlanName.toLowerCase());
            
            if(oldNameExists) {
                return {
                    response: 'privilage plan name already exist'
                }
            }
        }
       
        const updatePrivilage =  await PrivilagePlan.findByIdAndUpdate(_id, {
            privilagePlanName : privilagePlanName,
            productPlanId : productPlanId
        }, { new: true })
        // privious plan has permission deleted.
        const result = await privilagePlanHasPermission.deleteMany({ privilagePlanId: _id });

        // Add privilagePlanHasPermission
        permission.forEach(async(permission) => {
            const permissionId = permission.permissionId;
            const privilagePlanAdd = new privilagePlanHasPermission({
                privilagePlanId,
                permissionId
            });
           const result = await privilagePlanAdd.save();
        });

        const doerId = req.user._id;
        const loginUser = await User.findById(doerId);

        await commonFunction.eventLogFunction(
            'privilagePlan' ,
            doerId ,
            loginUser.fname ,
            req.ip , 
            companyId , 
            'Privilage plan update'
        );
        return {    
            response : 'Privilage plan updated successfully'
        }

    } catch (error) {
        throw error
    }
}


const privilagePlanAssignIsDefault = async(req ,res) => {
    try {
        const {companyId} = req.body;
        const _id = req.params.privilagePlanId;

         await PrivilagePlan.updateMany({ companyId }, { IsDefault: false });

        const result = await PrivilagePlan.findByIdAndUpdate( _id , {IsDefault : true }, { new: true });

        return {
            response : 'Privilage plan define as IsDefault updated successfully'
        }
    } catch (error) {
        throw error
    }
}


module.exports = {
    addPrivilagePlan , 
    getPrivilageList , 
    getPrivilagePlanByProductPlanId ,
    privilagePHPByPrivilageId,
    privilagePlanPatch,
    privilagePlanAssignIsDefault
}