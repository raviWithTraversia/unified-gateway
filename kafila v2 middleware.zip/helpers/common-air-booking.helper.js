const moment = require("moment");
const { saveLogInFile } = require("../utils/save-log");
const {
  convertDurationForCommonAPI,
  convertFlightDetailsForCommonAPI,
  convertPriceBreakupForCommonAPI,
  createAirPricingRequestBodyForCommonAPI,
} = require("./common-air-pricing.helper");
const { convertTravelTypeForCommonAPI } = require("./common-search.helper");
const SupplierCode = require("../models/supplierCode");
const CardDetailsModel = require("../models/CardDetails");
const { monthMap } = require("../utils/month-map");
const { getVendorList } = require("./credentials");

async function createAirBookingRequestBodyForCommonAPI(
  request,
  reqSegment,
  reqItinerary
) {
  try {
    saveLogInFile("booking-request.json", request);
    const { SearchRequest, PassengerPreferences } = request;
    // const reqSegment = SearchRequest.Segments?.[0];
    // const reqItinerary = request.ItineraryPriceCheckResponses?.[0];
    if (!reqItinerary || !reqSegment)
      throw new Error(
        "Invalid request data 'Itinerary[]' or 'Segment[]' missing"
      );
    const segmentMap = {};
    reqItinerary?.Sectors?.forEach((sector) => {
      segmentMap[`${sector.Departure.Code}-${sector.Arrival.Code}`] = sector;
    });
    saveLogInFile("segment-map.json", segmentMap);
    const travelType = convertTravelTypeForCommonAPI(SearchRequest.TravelType);
    const origin =
      travelType === "dom"
        ? reqItinerary?.Sectors?.[0]?.Departure?.CityCode
        : reqSegment.Origin;
    const destination =
      travelType === "dom"
        ? reqItinerary?.Sectors?.at(-1)?.Arrival?.CityCode
        : reqSegment.Destination;

    const pricingRQ = createAirPricingRequestBodyForCommonAPI({
      ...request.SearchRequest,
      Itinerary: [reqItinerary],
      // Itinerary: request.ItineraryPriceCheckResponses,
    });

    const requestBody = {
      typeOfTrip: SearchRequest.TypeOfTrip,
      credentialType: SearchRequest?.Authentication?.CredentialType ?? "TEST",
      travelType,
      companyId: SearchRequest?.Authentication?.CompanyId || "000000",
      // systemEntity: "KAFILA",
      // systemName: "KAFILA",
      // corpCode: "000000",
      // requestorCode: "000000",
      // empCode: "000000",
      uniqueKey: reqItinerary.UniqueKey,
      traceId: reqItinerary.TraceId,
      journey: [
        {
          journeyKey: reqItinerary.SearchID,
          origin,
          destination,
          issueTicket: !request.isHoldBooking,
          travelOrder: 1,
          ptcChanged: false,
          travellerDetails: PassengerPreferences?.Passengers?.map(
            (passenger, idx) =>
              convertTravelerDetailsForCommonAPI(
                passenger,
                idx,
                segmentMap,
                PassengerPreferences
              )
          ),
          itinerary: pricingRQ.requestBody.journey[0].itinerary,
          // itinerary: [
          //   {
          //     sessionKey: reqItinerary.SessionKey,
          //     uId: reqItinerary.UID,
          //     // uid: reqItinerary.UID,
          //     indexNumber: reqItinerary.IndexNumber,
          //     provider: reqItinerary.Provider,
          //     promoCodeType: reqItinerary.PromoCodeType,
          //     dealCode: reqItinerary.DealCode || "",
          //     airSegments: reqItinerary.Sectors.map((sector) => ({
          //       key: sector.key ?? "",
          //       travelTime: convertDurationForCommonAPI(sector.TravelTime),
          //       airlineCode: sector.AirlineCode,
          //       airlineName: sector.AirlineName,
          //       flyingTime: convertDurationForCommonAPI(sector.FlyingTime),
          //       departure: convertFlightDetailsForCommonAPI(sector.Departure),
          //       arrival: convertFlightDetailsForCommonAPI(sector.Arrival),
          //       operatingCarrier: sector.OperatingCarrier
          //         ? { code: sector.OperatingCarrier }
          //         : null,
          //       fltNum: sector.FltNum,
          //       equipType: sector.EquipType,
          //       group: sector.Group,
          //       baggageInfo: sector.BaggageInfo,
          //       handBaggage: sector.HandBaggage,
          //       offerDetails: null,
          //       classofService: sector.Class,
          //       cabinClass: sector.CabinClass,
          //       productClass: sector.ProductClass,
          //       noSeats: sector.Seats,
          //       fareBasisCode: sector.FareBasisCode,
          //       availabilitySource: sector.AvailabilitySource,
          //       isConnect: sector.IsConnect,
          //     })),
          //     priceBreakup: convertPriceBreakupForCommonAPI(
          //       reqItinerary.PriceBreakup
          //     ),
          //     freeSeat: reqItinerary.FreeSeat,
          //     freeMeal: reqItinerary.FreeMeal,
          //     carbonEmission: reqItinerary.CarbonEmission,
          //     baseFare: reqItinerary.BaseFare,
          //     taxes: reqItinerary.Taxes,
          //     totalPrice: reqItinerary.TotalPrice,
          //     valCarrier: reqItinerary.ValCarrier,
          //     refundableFare: reqItinerary.RefundableFare,
          //     sessionKey: reqItinerary.SessionKey,
          //     fareType: reqItinerary.FareType,
          //     promotionalCode: reqItinerary.PromotionalCode,
          //     fareFamily: reqItinerary.FareFamily,
          //     key: reqItinerary.Key,
          //     inPolicy: reqItinerary.InPolicy,
          //     isRecommended: reqItinerary.IsRecommended,
          //   },
          // ],
        },
      ],
      // gstDetails: ,
      // agencyInfo: {
      //   companyName: "",
      //   addressLine1: "",
      //   addressLine2: "",
      //   city: "",
      //   provinceState: "",
      //   postalCode: "",
      //   countryCode: "",
      //   emailAddress: "",
      //   homePhone: "",
      //   workPhone: "",
      //   agencyCardId: null,
      //   agentEmailAddress: "",
      //   isBtaTACard: false,
      // },
      rmFields: [],
      tourCode: null,
      isHoldBooking: request.isHoldBooking || false,
      fareMasking: false,
      vendorList: getVendorList(SearchRequest?.Authentication?.CredentialType),
    };
    if (PassengerPreferences?.GstData?.gstNumber) {
      requestBody.gstDetails = {
        fullName: PassengerPreferences?.GstData?.gstName || "",
        emailAddress: PassengerPreferences?.GstData?.gstEmail || "",
        homePhone: PassengerPreferences?.GstData?.gstmobile || "",
        workPhone: PassengerPreferences?.GstData?.gstmobile || "",
        gstNumber: PassengerPreferences?.GstData?.gstNumber || "",
        companyName: PassengerPreferences?.GstData?.gstName || "",
        addressLine1: PassengerPreferences?.GstData?.gstAddress || "",
        addressLine2: PassengerPreferences?.GstData?.gstAddressLine2 || "",
        city:
          PassengerPreferences?.GstData?.gstCity ||
          PassengerPreferences?.GstData?.GSTState ||
          "",
        provinceState: PassengerPreferences?.GstData?.GSTState || "",
        postalCode: PassengerPreferences?.GstData?.GSTPinCode || "",
        countryCode: PassengerPreferences?.GstData?.gstCountryCode || "",
      };
    }
    if (reqItinerary.ValCarrier === "AI") {
      const { cardDetails, error: cardDetailsError } = await getCardDetails({
        supplierCode: reqItinerary.Provider,
        credentialType: requestBody.credentialType,
      });
      saveLogInFile("card-info.json", { cardDetails, cardDetailsError });
      if (cardDetails) requestBody.journey[0].cardInfo = cardDetails;
    }
    saveLogInFile("book-request-body.json", requestBody);
    return { requestBody };
  } catch (error) {
    saveLogInFile("error-creating-common-booking-request.json", {
      stack: error.stack,
      message: error.message,
    });
    console.log({ error });
    return { error: error.message };
  }
}

function convertTravelerDetailsForCommonAPI(
  traveler,
  idx,
  segmentMap,
  PassengerPreferences
) {
  saveLogInFile("traveler.json", traveler);
  return {
    travellerId: "",
    type: traveler.PaxType,
    title: traveler.Title,
    firstName: traveler.FName,
    middleName: "",
    lastName: traveler.LName,
    seatPreferences: (traveler.Seat || [])
      .filter((pref) => segmentMap[`${pref.Src}-${pref.Des}`])
      .map((seat) => ({
        code: seat?.SeatCode,
        amount: seat?.TotalPrice,
        currency: seat?.Currency || "INR",
        paid: seat?.Paid,
        desc: seat?.SsrDesc,
        key: seat?.OI,
        origin: seat?.Src,
        destination: seat?.Des,
        airlineCode: seat?.FCode,
        flightNumber: seat?.FNo,
        wayType: seat?.Trip,
      })),
    baggagePreferences: (traveler.Baggage || [])
      .filter((pref) => {
        const segments = Object.values(segmentMap);
        let isSrc = false;
        let isDes = false;
        for (let segment of segments) {
          if (segment.Departure?.Code === pref.Src) isSrc = true;
          if (segment.Arrival?.Code === pref.Des) isDes = true;
        }
        return isSrc && isDes;
        // segmentMap[`${pref.Src}-${pref.Des}`]
      })
      .map((baggage) => ({
        name: baggage?.SsrDesc,
        code: baggage?.SsrCode,
        amount: baggage?.Price,
        currency: baggage?.Currency || "INR",
        paid: baggage?.Paid,
        desc: baggage?.SsrDesc,
        key: baggage?.key || "",
        origin: baggage?.Src,
        destination: baggage?.Des,
        airlineCode: baggage?.FCode,
        flightNumber: baggage?.FNo,
        wayType: baggage?.Trip,
      })),
    ffwdPreferences: (traveler.FastForward || [])
      .filter((pref) => segmentMap[`${pref.Src}-${pref.Des}`])
      .map((ffwd) => ({
        name: ffwd?.SsrDesc,
        code: ffwd?.SsrCode,
        amount: ffwd?.Price,
        currency: ffwd?.Currency || "INR",
        paid: ffwd?.Paid,
        desc: ffwd?.SsrDesc,
        key: ffwd?.key || "",
        origin: ffwd?.Src,
        destination: ffwd?.Des,
        airlineCode: ffwd?.FCode,
        flightNumber: ffwd?.FNo,
        wayType: ffwd?.Trip,
      })),
    mealPreferences: (traveler.Meal || [])
      .filter((pref) => segmentMap[`${pref.Src}-${pref.Des}`])
      .map((meal) => ({
        name: meal?.SsrDesc,
        code: meal?.SsrCode,
        amount: meal?.Price,
        currency: meal?.Currency || "INR",
        paid: meal?.Paid,
        desc: meal?.SsrDesc,
        key: meal?.key || "",
        origin: meal?.Src,
        destination: meal?.Des,
        airlineCode: meal?.FCode,
        flightNumber: meal?.FNo,
        wayType: meal?.Trip,
      })),
    dob: traveler.Dob ?? "",
    gender: traveler.Gender?.at?.(0)?.toUpperCase?.() || "M",
    passportDetails: traveler?.Optional?.PassportNo
      ? {
          number: traveler?.Optional?.PassportNo ?? "",
          issuingCountry: traveler?.Optional?.ResidentCountry,
          expiryDate: moment(traveler?.Optional?.PassportExpiryDate).format(
            "YYYY-MM-DD"
          ),
          issueDate: moment(traveler?.Optional?.PassportIssuedDate).format(
            "YYYY-MM-DD"
          ),
        }
      : {
          number: "",
          issuingCountry: "",
          expiryDate: "",
          issueDate: "",
        },
    contactDetails:
      idx === 0
        ? {
            // address1: traveler.AddressLine1 ?? null,
            // address2: traveler.AddressLine2 ?? null,
            // city: traveler.City ?? null,
            // state: traveler.State ?? null,
            // country: traveler.Country ?? null,
            // countryCode: traveler.CountryCode ?? null,
            email: PassengerPreferences.PaxEmail ?? null,
            phone: PassengerPreferences.PaxMobile ?? null,
            mobile: PassengerPreferences.PaxMobile ?? null,
            // postalCode: traveler.PostalCode ?? null,
            // isdCode: traveler.IsdCode ?? null,
          }
        : {
            address1: traveler.AddressLine1 ?? null,
            address2: traveler.AddressLine2 ?? null,
            city: traveler.City ?? null,
            state: traveler.State ?? null,
            country: traveler.Country ?? null,
            countryCode: traveler.CountryCode ?? null,
            email: traveler.PaxEmail ?? null,
            phone: traveler.PaxMobile ?? null,
            mobile: traveler.PaxMobile ?? null,
            postalCode: traveler.PostalCode ?? null,
            isdCode: traveler.IsdCode ?? null,
          },
    frequentFlyer: traveler.FrequentFlyer ?? null,
    nationality: traveler.Nationality ?? "IN",
    department: traveler.Department ?? "",
    designation: traveler.Designation ?? "",
  };
}

function convertBookingResponse(request, response, reqSegment, isINTRoundtrip) {
  // const tickets = response?.data?.journey?.[0]?.travellerDetails[0]?.eTicket;
  // const src = request.SearchRequest.Segments[0].Origin; // TODO: needs to be dynamic
  // console.log(response);

  const src = reqSegment?.Origin || "";
  const des = reqSegment?.Destination || "";
  // const des = request.SearchRequest.Segments[0].Destination; // TODO: needs to be dynamic
  const pnrs = response?.data?.journey?.[0]?.recLoc;
  const bookingStatus =
    response?.data?.journey?.[0]?.bookingStatus ?? "Pending";
  const errorMessage =
    response?.data?.journey?.[0]?.errorList?.join?.(", ") || null;
  // response?.data?.journey?.[0]?.reason ||
  // response?.data?.journey?.[0]?.message ||
  // response?.data?.journey?.[0]?.messages ||
  ("");

  console.log({ errorMessage });

  const provider = response?.data?.journey?.[0]?.itinerary?.[0]?.provider;
  let [PNR, APnr, GPnr] = [null, null, null];
  if (pnrs?.length) {
    PNR = pnrs.find((pnr) => pnr.type === "GDS")?.pnr ?? null;
    // APnr = pnrs.find((pnr) => pnr.type === "Airline")?.pnr ?? null;
    GPnr =
      pnrs.find((pnr) => pnr.type === (provider === "1AN" ? "Airline" : "GDS"))
        ?.pnr ?? null;
  }
  // if (tickets.length) {
  // }
  const lastTicketingTime =
    response?.data?.journey?.[0]?.itinerary?.[0]?.lastTicketingTime || "";
  const travelerDetails = response?.data?.journey?.[0]?.travellerDetails;
  try {
    const data = {
      Status: bookingStatus == "Confirm" ? "Success" : bookingStatus,
      BookingInfo: {
        BookingId: "",
        BookingRemark: errorMessage || "",
        PNR,
        APnr,
        GPnr,
        SalePurchase: "",
        LastTicketingTime: lastTicketingTime,
      },
      PaxInfo: updatePassengerDetails(
        request?.PassengerPreferences || { Passengers: [] },
        travelerDetails,
        src,
        des,
        isINTRoundtrip
      ),
    };
    data.BookingInfo.IsError =
      data.Status == "Failed" || data.Status === "Pending";

    data.BookingInfo.CurrentStatus =
      data.Status == "Hold"
        ? "HOLD"
        : data?.Status?.toUpperCase?.() || data.Status || "Pending";
    if (travelerDetails?.[0]?.eTicket?.length)
      data.BookingInfo.CurrentStatus = "CONFIRMED";
    data.ErrorMessage = errorMessage || "";
    data.WarningMessage = data.ErrorMessage;
    return { data };
  } catch (error) {
    saveLogInFile("error-converting-booking-response.json", {
      stack: error.stack,
      message: error.message,
    });
    return {
      data: {
        Status: bookingStatus == "Confirm" ? "Success" : bookingStatus,
        BookingInfo: {
          BookingId: "",
          BookingRemark: errorMessage || "",
          PNR,
          APnr,
          GPnr,
          SalePurchase: "",
          IsError: true,
          CurrentStatus: "Pending",
          ErrorMessage: errorMessage || error.message,
          WarningMessage: errorMessage || error.message,
        },
        PaxInfo: updatePassengerDetails(
          request?.PassengerPreferences || { Passengers: [] },
          travelerDetails,
          src,
          des
        ),
      },
    };
  }
}

function updatePassengerDetails(
  passengerPreferences,
  travelerDetails,
  src,
  des,
  isINTRoundtrip
) {
  if (!travelerDetails?.length) return passengerPreferences;
  const updatedPassengerPreferences = {
    ...passengerPreferences,
    Passengers:
      passengerPreferences?.Passengers?.map?.((pax, idx) => {
        if (!travelerDetails?.[idx]?.eTicket?.length) return pax;
        const ticketDetails =
          travelerDetails?.[idx]?.eTicket?.map?.((ticket) => ({
            ticketNumber: ticket.eTicketNumber,
            src,
            des,
          })) || [];

        // ? save same ticket number for international tickets
        if (
          isINTRoundtrip &&
          ticketDetails?.length === 1 &&
          ticketDetails?.[0]?.ticketNumber
        ) {
          ticketDetails.push({
            ticketNumber: ticketDetails[0].ticketNumber,
            src: des,
            des: src,
          });
        }
        const EMDDetails =
          travelerDetails[idx]?.emd?.map?.((emd) => {
            let type = emd.type.toLowerCase();
            if (type !== "seat" && type !== "baggage") type = "ffwd";
            return {
              EMDNumber: emd.EMDNumber || emd.emdNumber || "",
              IssuedDate: emd.IssuedDate || emd.IssueDate || "",
              amount: emd.amount || 0,
              type,
              currency: emd.currency || "",
              origin: emd.departure || "",
              destination: emd.arrival || "",
              status: "confirmed",
            };
          }) || [];
        // if (
        //   ticketDetails?.length &&
        //   !pax.Optional?.ticketDetails?.some((ticket) => ticket?.ticketNumber)
        // ) {
        //   pax.Optional.ticketDetails = ticketDetails;
        // } else {
        //   pax.Optional.ticketDetails = [
        //     ...pax.Optional.ticketDetails,
        //     ticketDetails,
        //   ];
        // }
        // if (
        //   EMDDetails.length &&
        //   !pax.Optional?.EMD?.some((emd) => emd?.EMDNumber)
        // ) {
        //   pax.Optional.EMDDetails = EMDDetails;
        // } else {
        //   pax.Optional.EMDDetails = [...pax.Optional.EMDDetails, EMDDetails];
        // }
        // return pax;
        saveLogInFile("tickets.json", { ticketDetails, EMDDetails });
        return {
          ...pax,
          Optional: {
            ticketDetails,
            EMDDetails,
            // ...pax.Optional = {}
          },
        };
      }) || [],
  };
  return updatedPassengerPreferences;
}

async function getCardDetails({ supplierCode, credentialType }) {
  try {
    if (!supplierCode || !credentialType)
      throw new Error("Invalid Supplier Code OR Credential Type");

    const supplier = await SupplierCode.findOne({ supplierCode });
    if (!supplier) throw new Error("Supplier Not Found");

    const cardDetails = await CardDetailsModel.findOne({
      ApplicableOnBookingSupplier: supplier._id,
      credentialType,
      isEnabled: true,
    });
    if (!cardDetails)
      throw new Error(
        `${supplierCode} ${credentialType} Card Details Not Found`
      );
    let { cardNumber, expiryMonth, expiryYear, cardType } = cardDetails;
    if (!cardNumber || !expiryMonth || !expiryYear)
      throw new Error(
        `${supplierCode} ${credentialType} Card Details Are Invalid`
      );
    expiryMonth = monthMap[expiryMonth.toLowerCase?.()];
    if (!expiryMonth) throw new Error("Invalid Expiry Month");

    return {
      cardDetails: {
        cardNumber,
        code: cardType,
        expiryYear: expiryYear.slice(-2),
        expiryMonth,
      },
    };
  } catch (error) {
    saveLogInFile("card-error.json", {
      message: error.message,
      stack: error.stack,
    });
    console.error({ errorFetchingCardDetails: error });
    return { error: error.message };
  }
}

module.exports = {
  createAirBookingRequestBodyForCommonAPI,
  convertTravelerDetailsForCommonAPI,
  convertBookingResponse,
};
