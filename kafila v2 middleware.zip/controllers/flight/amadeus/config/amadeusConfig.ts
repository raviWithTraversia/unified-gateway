// export default {
//     apiUrl: process.env.AMADEUS_API_URL,
//     apiKey: process.env.AMADEUS_API_KEY,
//   };
  