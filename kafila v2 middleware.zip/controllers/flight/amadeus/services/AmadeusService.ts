// import axios from 'axios';
// import amadeusConfig from '../config/amadeusConfig';

// class AmadeusService {
//   static async getFlights() {
//     const response = await axios.get(`${amadeusConfig.apiUrl}/flights`, {
//       headers: {
//         Authorization: `Bearer ${amadeusConfig.apiKey}`,
//       },
//     });
//     return response.data;
//   }

//   static async createBooking(data: any) {
//     const response = await axios.post(`${amadeusConfig.apiUrl}/booking`, data, {
//       headers: {
//         Authorization: `Bearer ${amadeusConfig.apiKey}`,
//       },
//     });
//     return response.data;
//   }
// }

// export default AmadeusService;
