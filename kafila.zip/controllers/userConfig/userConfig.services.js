const company = require('../../models/Company');

const updateConfig = async (req,res) => {
try{
     const {creditBalance , accountCode} = req.body;
     
               
 }catch(error){
           
}
};

module.exports = {
    updateConfig 
}