const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({       
    company_ID: {
        type : mongoose.Schema.Types.ObjectId,
        ref: 'Company'
    },
    userType: {
        type: String,
        default: null
    },
    login_Id: {
        type: String,
        default: null
    },
    email: {
        type: String,
        required: true,
    },
    deactivation_Date: {
        type: String,
        default: null
    },
    logoURI: {
      type: String,
      default: null
    },
    roleId: {
        type : mongoose.Schema.Types.ObjectId,
        ref: 'Role'
    },
    title: {
        type : String,
        required : true
    },
    fname:  {
        type : String,
        required : true
    },
    lastName:  {
        type : String,
        required : true
    },
    password:  {
        type : String,
        required : true
    },
    securityStamp: {
        type: String,
        default: null
    },
    phoneNumber:  {
        type : String,
        required : true
    },
    twoFactorEnabled: {
        type: Boolean,
        default: null
    },
    lockoutEnabled: {
        type: Boolean,
        default: null
    },
    accessfailedCount: {
        type: Number,
        default: null
    },
    emailConfirmed: {
        type : Boolean,
        default : false
    },
    phoneNumberConfirmed: {
        type : Boolean,
        default : false
    },
    userStatus: {
        type: String,
        default: null
    },
    userPanName: {
        type: String,
        default: null
    },
    userPanNumber: {
        type: String,
        default: null
    },
    created_Date: {
        type: Date,
         default: Date.now,
    },
    lastModifiedDate: {
        type: Date,
        default: Date.now,
    },
    userModifiedBy: {
        type : mongoose.Schema.Types.ObjectId,
        ref : 'User'
    },
    last_LoginDate:  {
        type: Date,
        default: Date.now,
    },
    activation_Date: {
        type: Date,
        default: Date.now,
    },
    sex: {
      type : String,
      default: null  
    },
    dob: {
        type: Date  
    },
    nationality: {
        type : String,
        default : "IN"
    },
    deviceToken: {
        type : String,
        default: null 
    },
    deviceID: {
        type : String,
        default: null 
    },
    user_planType: { /// need to be discuss
        type : Number,
        default : 1
    },
    sales_In_Charge: {
        type: Boolean,
        default: false
    },
    personalPanCardUpload: {
        type: String,
        default: null
    },
    resetToken: String,
    ip_address : String  
}, {
    timestamps: true // Adds created_at and updated_at fields
  });

const User = mongoose.model("User", userSchema);

module.exports = User; // Export the User model

